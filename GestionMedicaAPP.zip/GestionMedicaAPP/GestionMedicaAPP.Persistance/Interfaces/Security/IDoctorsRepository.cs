﻿using GestionMedicaAPP.Domain.Entities.Security;
using GestionMedicaAPP.Domain.Repositories;

namespace GestionMedicaAPP.Persistance.Interfaces.Security
{
    public interface IDoctorsRepository : IBaseRepository<Doctors>
    {
    }
}
