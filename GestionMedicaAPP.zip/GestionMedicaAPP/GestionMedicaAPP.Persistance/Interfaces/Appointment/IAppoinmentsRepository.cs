﻿using GestionMedicaAPP.Domain.Entities.Appointmet;
using GestionMedicaAPP.Domain.Repositories;

namespace GestionMedicaAPP.Persistance.Interfaces.Appointment
{
    public interface IAppointmentsRepository : IBaseRepository<AppointmentsModel>
    {
    }
}
