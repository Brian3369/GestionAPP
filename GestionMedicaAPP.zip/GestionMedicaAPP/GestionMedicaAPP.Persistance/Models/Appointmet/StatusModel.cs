﻿namespace GestionMedicaAPP.Domain.Entities.Appointmet
{
    public sealed class StatusModel
    {
        public int StatusID { get; set; }
        public string StatusName { get; set; }
    }
}
