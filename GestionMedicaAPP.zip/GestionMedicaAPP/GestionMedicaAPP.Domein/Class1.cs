﻿namespace GestionMedicaAPP.Domein
{
    public class Class1
    {

    }
}
