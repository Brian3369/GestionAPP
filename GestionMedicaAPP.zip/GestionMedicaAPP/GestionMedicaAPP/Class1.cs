﻿namespace GestionMedicaAPP
{
    public class Class1
    {

    }
}
